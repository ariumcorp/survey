import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.ariumcorp.base.proyect",
  appName: "base-proyect",
  webDir: "build",
};

export default config;
