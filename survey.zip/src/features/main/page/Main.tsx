import { AnimatedPage } from "components";

export const Main = () => {
  return <AnimatedPage>Principal</AnimatedPage>;
};
