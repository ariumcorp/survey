export * from "./auth/page/Login";
export * from "./layout/page/Layout";
export * from "./main/page/Main";
export * from "./survey-builder/page/SurveyConfig";
export * from "./survey-list/page/Surveys";
export * from "./answer-survey/page/AnswerSurvey";
export * from "./survey-dashboard/page/SurveyDashboard";
