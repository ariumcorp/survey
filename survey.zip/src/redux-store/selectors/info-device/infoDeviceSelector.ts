import { ReduxState } from "redux-store/store";

export const infoDeviceSelector = (state: ReduxState) => state.infoDeviceSlice;
