import { Slice } from "../utils/enums";

// import { testApi } from "./api";
export const reduxPersistWhiteList = [Slice.Auth, Slice.AccessSlice];
