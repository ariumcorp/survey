import { createAction } from "@reduxjs/toolkit";
export const resetApp = createAction("app/reset");
