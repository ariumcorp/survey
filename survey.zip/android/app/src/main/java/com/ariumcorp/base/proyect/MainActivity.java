package com.ariumcorp.base.proyect;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
